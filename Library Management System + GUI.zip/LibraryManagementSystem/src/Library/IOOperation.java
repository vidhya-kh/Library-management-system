package Library;

public interface IOOperation {
	
	public void oper(Database database, User user);

}
